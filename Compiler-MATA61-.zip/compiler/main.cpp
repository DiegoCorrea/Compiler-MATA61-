#include <iostream>
#include <string>
#include <stdio.h>

int main (){

  return 0;
}