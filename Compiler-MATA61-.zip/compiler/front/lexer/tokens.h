#define ERROR 404
#define KEY 1
#define DEC 2
#define SYM 3
#define ID 4
#define COMMENT 5
#define WHITESPACE 6